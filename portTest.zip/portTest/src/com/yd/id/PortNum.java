package com.yd.id;


public class PortNum {
	ID id;
	int portNum;
	
	public PortNum(ID id , int portNum) {
		this.id = id;
		this.portNum = portNum;
	}
}
