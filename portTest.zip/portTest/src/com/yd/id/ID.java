package com.yd.id;

public class ID {
	protected String ID;
	protected int[] port= new int[2];
	
	public ID(String ID , int[] port) {
		this.ID = ID;
		this.port = port.clone();
	}
	
	public String getID() {
		return ID;
	}
	
	public int[] getPort() {
		return port;
	}
	
	@Override
	public String toString() {
		String infor = ID + "," + port[0] + "," + port[1];
		return infor;
	}
}
