package com.yd;

import java.util.List;
import java.util.Scanner;
import java.io.*;
import java.net.URL;
import java.nio.file.Path;
import java.util.ArrayList;

import javax.print.DocFlavor.INPUT_STREAM;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.text.AbstractDocument.BranchElement;

import com.sun.mail.iap.Response;
import com.yd.id.*;


/**
 * Servlet implementation class Yd
 */
@WebServlet("/Yd")
public class Yd extends HttpServlet {
	ArrayList<ID> idList = null;
	
	public  boolean checkandCreateID(String id, int port1, int port2) throws IOException {
		for (ID id1 : idList) {
			String stu = id1.getID();
			int p1 = id1.getPort()[0];
			int p2 = id1.getPort()[1];
			if (stu.equals(id) || p1 == port1 || p1 == port2 || p2 == port1 || p2 == port2 || port1 == port2) {
				return false;
			}
		}
		
		int[] port = {port1,port2};
		ID id2 =new ID(id, port);
		idList.add(id2);
		
		
		
		return true;
	}
	
	@Override
		public void init() throws ServletException {
			
			try {
				fileinput();
				
				
			} catch (NumberFormatException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	private void fileinput() throws NumberFormatException, IOException {
		ArrayList<String> userList = new ArrayList<String>();
		ArrayList<PortNum> portList = new ArrayList<PortNum>();
		this.idList = new  ArrayList<ID>();
		userList.clear();
		portList.clear();
		idList.clear();

		
		Scanner scanner = new Scanner(new FileInputStream("output.txt"));
		int i = 0;
		String numString = "";
		
		while (scanner.hasNextLine()) {
			numString =scanner.nextLine();
			if (!numString.equals("")) {
				String[] single = numString.split(",");
				userList.add(single[0]);
				checkandCreateID(single[0], Integer.parseInt(single[1]), Integer.parseInt(single[2]));
			}
			
		}
		System.out.println(idList.toString());
		
		this.getServletContext().setAttribute("local", idList);
	}
	
	private void fileoutput() throws IOException { 
		ArrayList<ID> outID = (ArrayList<ID>) this.getServletContext().getAttribute("local");
		String outString = "";
		for (ID id : outID) {
			outString += id.toString() + "\n";
		}
		System.out.println(outString);
		
		Writer outWriter = new FileWriter(new File("output.txt"));
		outWriter.write(outString);
		outWriter.close();
		
	}
	
	@Override
		protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			
			String method = req.getParameter("method");
			if (method == null || "".equals(method)) {
				startup(req, resp);
			}else if ("check".equals(method)) {
				check(req, resp);
			}else if ("cleanData".equals(method)) {
				cleanData(req,resp);
			}
		}
	

	/**
	 * for clean all the date on the output text file
	 * @param req
	 * @param resp
	 * @throws IOException
	 */
	protected void cleanData(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		File file = new File("output.txt");
		if (file.exists()) {
			file.delete();
			file.createNewFile();
		}else {
			file.createNewFile();
		}
			
		idList.clear();
		
		resp.sendRedirect(req.getContextPath() + "/");;
		
	}

	protected void startup(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Integer> num = new ArrayList<Integer>();
		num.add(1);
		ArrayList<ID> list = (ArrayList<ID>) this.getServletContext().getAttribute("local");

		request.setAttribute("num", list);
		
		request.getRequestDispatcher("/index.jsp").forward(request, response);
//		response.sendRedirect(request.getContextPath() + "/index.jsp");
	}
	
	/**
	 * verify the inputed student number and port number and add in the output.txt and send the e-mail
	 * @param request
	 * @param response
	 * @throws IOException
	 * @throws ServletException
	 */
	protected void check(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		response.setContentType("text/html ; charset = utf-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
//		//set header can be used in 
//		response.setHeader("Access-Control-Allow-Origin", "*");
//		//* mean all the field's request can be accept
//		response.setHeader("Access-Control-Allow-Methods", "GET,POST");
		
		//Receive Json
		String name = request.getParameter("name");
		String port1 = request.getParameter("port1");
		String port2 = request.getParameter("port2");
		System.out.println(name+port1+port2);
		int p1 = Integer.parseInt(port1.trim());
		int p2 = Integer.parseInt(port2.trim());
		if (checkandCreateID(name, p1, p2)) {
			fileoutput();
			
			response.getWriter().write("<script>alert('success');history.back();location='Yd'</script>");
		
			
			sendbyGmail.excute(name, p1, p2);
		}else {
			response.getWriter().write("<script>alert('unsuccess');history.back();</script>");
		}
	}
	

}
